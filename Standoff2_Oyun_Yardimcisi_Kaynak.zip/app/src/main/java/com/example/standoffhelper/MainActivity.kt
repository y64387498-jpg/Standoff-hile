package com.example.standoffhelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val gamePackage = "com.axlebolt.standoff2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }

        val title = TextView(this).apply {
            text = "STANDOFF 2"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "GAME ASSISTANT"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        val start = Button(this).apply {
            text = "BAŞLAT"
            textSize = 18f
            isAllCaps = false
            setOnClickListener { startGame() }
        }

        val note = TextView(this).apply {
            text = "ESP Demo yalnızca görsel simülasyondur; gerçek oyuncuları algılamaz."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(12, 22, 12, 0)
        }

        page.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        page.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 42 })
        page.addView(start, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 58
        ))
        page.addView(note, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(page)
    }

    private fun startGame() {
        if (!Settings.canDrawOverlays(this)) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(permissionIntent)
            Toast.makeText(this, "Diğer uygulamaların üzerinde gösterme iznini aç, sonra BAŞLAT'a tekrar bas.", Toast.LENGTH_LONG).show()
            return
        }

        startService(Intent(this, OverlayService::class.java))

        val launchIntent = packageManager.getLaunchIntentForPackage(gamePackage)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Standoff 2 bulunamadı. Oyunun yüklü olduğundan emin ol.", Toast.LENGTH_LONG).show()
        }
    }
}
