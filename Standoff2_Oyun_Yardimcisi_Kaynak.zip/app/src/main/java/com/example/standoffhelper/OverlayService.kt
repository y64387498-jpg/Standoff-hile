package com.example.standoffhelper

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: FrameLayout? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        if (overlay != null) return

        val root = FrameLayout(this)
        val demo = DemoDrawingView()
        root.addView(demo, FrameLayout.LayoutParams(190, 210))

        val close = TextView(this).apply {
            text = "×"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 55, 65))
            gravity = Gravity.CENTER
            setOnClickListener { stopSelf() }
        }
        val closeParams = FrameLayout.LayoutParams(42, 42, Gravity.TOP or Gravity.END)
        root.addView(close, closeParams)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 140
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.x
                        startY = params.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - downX).toInt()
                        params.y = startY + (event.rawY - downY).toInt()
                        windowManager.updateViewLayout(root, params)
                        return true
                    }
                }
                return false
            }
        })

        overlay = root
        windowManager.addView(root, params)
    }

    override fun onDestroy() {
        overlay?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class DemoDrawingView : View(this@OverlayService) {
        private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 230, 130)
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 13f
        }
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(190, 16, 24, 32)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 12f, 12f, bgPaint)
            canvas.drawText("ESP DEMO", 14f, 23f, textPaint)
            canvas.drawRect(54f, 48f, 136f, 174f, boxPaint)
            canvas.drawLine(95f, 48f, 95f, 30f, boxPaint)
            canvas.drawText("SIMÜLASYON", 49f, 194f, textPaint)
        }
    }
}
